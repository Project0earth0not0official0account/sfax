package sfax.models;

public class PackageManifest {
    private String name;
    private String version;
    private String[] dependencies;
    private String architecture;

    
    public String getName() { return name; }
    public String getVersion() { return version; }
    public String[] getDependencies() { return dependencies; }
    public String getArchitecture() { return architecture; }
}