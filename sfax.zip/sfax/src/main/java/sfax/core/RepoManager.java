package sfax.core;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class RepoManager {
    private static final String REPO_BASE_URL = "https://project0earth0not0official0account.github.io/sfax/repo/arm64/";
    private static final Gson gson = new Gson();

    public static JsonObject getPackageInfo(String packageName) {
        try {
            URL url = new URL(REPO_BASE_URL + "packages.json");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            Scanner scanner = new Scanner(conn.getInputStream());
            StringBuilder response = new StringBuilder();
            while (scanner.hasNextLine()) {
                response.append(scanner.nextLine());
            }
            scanner.close();

            JsonArray packages = gson.fromJson(response.toString(), JsonArray.class);
            for (JsonElement pkg : packages) {
                JsonObject obj = pkg.getAsJsonObject();
                if (obj.get("name").getAsString().equals(packageName)) {
                    return obj;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}