package sfax.core;

import sfax.models.PackageManifest;
import com.google.gson.Gson;
import java.io.*;
import java.util.zip.ZipFile;
import java.util.zip.ZipEntry;

public class PackageLoader {
    private static final Gson gson = new Gson();

    public static PackageManifest loadManifest(File sfxFile) throws IOException {
        try (ZipFile zip = new ZipFile(sfxFile)) {
            ZipEntry manifestEntry = zip.getEntry("manifest.json");
            if (manifestEntry == null) throw new IOException("Manifest not found");

            try (InputStream is = zip.getInputStream(manifestEntry);
                 BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {
                return gson.fromJson(reader, PackageManifest.class);
            }
        }
    }

    public static void extractPackage(File sfxFile, String destDir) throws IOException {
        
    }
}