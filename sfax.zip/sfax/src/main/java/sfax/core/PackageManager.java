package sfax.core;

import sfax.models.PackageManifest;
import java.io.File;

public class PackageManager {
    public static void installPackage(String packageName) {
        JsonObject pkgInfo = RepoManager.getPackageInfo(packageName);
        if (pkgInfo == null) {
            System.out.println("Package not found: " + packageName);
            return;
        }

        String version = pkgInfo.get("version").getAsString();
        String downloadUrl = RepoManager.REPO_BASE_URL + packageName + "-" + version + ".sfx";

        try {
            // Скачать .sfx файл
            File sfxFile = downloadPackage(downloadUrl);

            // Загрузить манифест
            PackageManifest manifest = PackageLoader.loadManifest(sfxFile);

            // Проверить архитектуру
            if (!"arm64".equals(manifest.getArchitecture())) {
                throw new IOException("Unsupported architecture");
            }

            // Установить зависимости
            for (String dep : manifest.getDependencies()) {
                installPackage(dep);
            }

            // Распаковать и установить файлы
            PackageLoader.extractPackage(sfxFile, TermuxUtils.getInstallPath());

            System.out.println("Installed: " + packageName + "@" + version);
        } catch (Exception e) {
            System.out.println("Installation failed: " + e.getMessage());
        }
    }

    private static File downloadPackage(String url) {
        // Реализация загрузки (используйте HttpURLConnection)
        return new File("downloaded.sfx");
    }
}