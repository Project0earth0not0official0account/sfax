package sfax.cli;

import sfax.core.PackageManager;

public class Main {
    public static void main(String[] args) {
        if (args.length == 0) {
            printHelp();
            return;
        }

        switch (args[0]) {
            case "install":
                if (args.length < 2) {
                    System.out.println("Usage: sfax install <package>");
                    return;
                }
                PackageManager.installPackage(args[1]);
                break;
            case "help":
                printHelp();
                break;
            default:
                System.out.println("Unknown command: " + args[0]);
        }
    }

    private static void printHelp() {
        System.out.println("sfax - Package Manager for Termux (arm64)");
        System.out.println("Commands:");
        System.out.println("  install <package>  Install a package");
    }
}